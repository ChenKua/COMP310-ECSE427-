//    Final Project COMP 310
//    Your Name: Kua Chen
//    Your McGill ID: 260856888
//
//    DISK_driver_problem2.h
//

#ifndef DISK_driver_problem2_h
#define DISK_driver_problem2_h

// Close file
void close_EXAM(int index);


#endif /* DISK_driver_problem2_h */